/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Mail, Key, User, ArrowRight, ShieldCheck, HelpCircle } from 'lucide-react';

interface AuthPagesProps {
  initialMode: 'login' | 'register';
  onAuthSuccess: (token: string, userData: any) => void;
  setCurrentTab: (tab: string) => void;
}

export default function AuthPages({
  initialMode,
  onAuthSuccess,
  setCurrentTab
}: AuthPagesProps) {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>(initialMode);
  
  // State elements
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const [infoMessage, setInfoMessage] = useState('');
  const [loading, setLoading] = useState(false);

  // Form submission handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setInfoMessage('');
    setLoading(true);

    if (mode === 'forgot') {
      if (!email) {
        setError('Please enter a valid email address to request code.');
        setLoading(false);
        return;
      }
      setTimeout(() => {
        setInfoMessage('A password recovery link has been dispatched to: ' + email + '. Please verify your inbox.');
        setLoading(false);
      }, 900);
      return;
    }

    try {
      const endpoint = mode === 'login' ? '/api/login' : '/api/register';
      const payload = mode === 'login' ? { email, password } : { email, password, name };

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });

      const resData = await response.json();

      if (!response.ok) {
        throw new Error(resData.error || 'Server rejected with status: ' + response.status);
      }

      if (mode === 'login') {
        const { token, user } = resData;
        onAuthSuccess(token, user);
        setCurrentTab('dashboard');
      } else {
        setInfoMessage('Account registered successfully! Initiating auto log session...');
        // Auto sign-in
        const tokenResponse = await fetch('/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });
        const loginData = await tokenResponse.json();
        if (tokenResponse.ok) {
          onAuthSuccess(loginData.token, loginData.user);
          setCurrentTab('dashboard');
        } else {
          setMode('login');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Network anomaly detected while communicating with DeepShield HQ.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-panel" className="relative min-h-[calc(100vh-65px)] flex items-center justify-center bg-[#F8FAFC] px-4 py-12 text-slate-800">
      
      <div className="w-full max-w-sm space-y-7 rounded-xl border border-slate-200 bg-white p-7 sm:p-8 shadow-sm">
        
        {/* Brand visual header */}
        <div className="text-center">
          <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white shadow-sm shadow-blue-500/20">
            <Shield className="h-5.5 w-5.5" />
          </div>
          <h2 className="mt-4 text-xl font-bold tracking-tight text-slate-900 leading-none">
            {mode === 'login' ? 'Access Shield Console' : mode === 'register' ? 'Register Specialist' : 'Account Recovery'}
          </h2>
          <p className="mt-2 text-xs text-slate-500 font-light">
            {mode === 'login' 
              ? 'Authorized forensic specialists gateway' 
              : mode === 'register' 
                ? 'Join our media authentication workspace' 
                : 'Request an ephemeral access hash token'}
          </p>
        </div>

        {/* Status Alerts */}
        {error && (
          <div id="auth-error-block" className="rounded-lg border border-red-200 bg-red-50 p-3.5 text-xs text-red-700 font-medium">
            ⚠️ {error}
          </div>
        )}
        
        {infoMessage && (
          <div id="auth-info-block" className="rounded-lg border border-emerald-200 bg-emerald-50 p-3.5 text-xs text-emerald-700 font-medium">
            ✓ {infoMessage}
          </div>
        )}

        {/* Demo Credentials Cheat Sheet */}
        {mode === 'login' && (
          <div className="bg-blue-50/50 border border-blue-100 p-3 rounded-lg text-left">
            <span className="text-[10px] font-bold text-blue-700 uppercase tracking-wider block mb-1">Testing Credentials:</span>
            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-600">
              <div>
                <span className="text-slate-800 font-bold block">User Account:</span>
                demo@deepshield.ai <br />
                Pswd: demo123
              </div>
              <div className="border-l border-slate-200 pl-2">
                <span className="text-purple-700 font-bold block">Admin Account:</span>
                admin@deepshield.ai <br />
                Pswd: admin123
              </div>
            </div>
          </div>
        )}

        {/* Form Inputs */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {mode === 'register' && (
            <div className="space-y-1 text-left">
              <label className="text-[11px] font-bold text-slate-550 uppercase tracking-wide block">Full Name</label>
              <div className="relative rounded-lg border border-slate-300 bg-white focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition duration-150">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <User className="h-4 w-4" />
                </div>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Officer J. Hawk"
                  className="block w-full py-2 pl-9 pr-3 text-xs text-slate-800 placeholder-slate-400 bg-transparent border-0 focus:outline-none focus:ring-0"
                />
              </div>
            </div>
          )}

          <div className="space-y-1 text-left">
            <label className="text-[11px] font-bold text-slate-550 uppercase tracking-wide block">Security Email</label>
            <div className="relative rounded-lg border border-slate-300 bg-white focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition duration-150">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                <Mail className="h-4 w-4" />
              </div>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="specialist@deepshield.ai"
                className="block w-full py-2 pl-9 pr-3 text-xs text-slate-800 placeholder-slate-400 bg-transparent border-0 focus:outline-none focus:ring-0"
              />
            </div>
          </div>

          {mode !== 'forgot' && (
            <div className="space-y-1 text-left">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-slate-550 uppercase tracking-wide block">Passcode</label>
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-[10px] text-blue-600 hover:underline font-semibold"
                  >
                    Forgot code?
                  </button>
                )}
              </div>
              <div className="relative rounded-lg border border-slate-300 bg-white focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition duration-150">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Key className="h-4 w-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="block w-full py-2 pl-9 pr-3 text-xs text-slate-800 placeholder-slate-400 bg-transparent border-0 focus:outline-none focus:ring-0"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="group w-full relative flex items-center justify-center gap-2 rounded-lg bg-blue-600 hover:bg-blue-700 py-2.5 text-xs font-semibold text-white shadow-sm transition duration-150 disabled:opacity-40 cursor-pointer"
          >
            {loading ? (
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
            ) : (
              <>
                <span>
                  {mode === 'login' ? 'Confirm Credentials' : mode === 'register' ? 'Submit Enrollment' : 'Request Token Reset'}
                </span>
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </>
            )}
          </button>
        </form>

        {/* Tab switch footer */}
        <div className="pt-4 border-t border-slate-150 text-center text-xs">
          {mode === 'login' ? (
            <p className="text-slate-500">
              New to DeepShield?{' '}
              <button
                type="button"
                onClick={() => { setMode('register'); setError(''); }}
                className="text-blue-600 hover:underline font-semibold"
              >
                Enroll specialist registry
              </button>
            </p>
          ) : mode === 'register' ? (
            <p className="text-slate-500">
              Already registered?{' '}
              <button
                type="button"
                onClick={() => { setMode('login'); setError(''); }}
                className="text-blue-600 hover:underline font-semibold"
              >
                Log console session
              </button>
            </p>
          ) : (
            <button
              type="button"
              onClick={() => { setMode('login'); setError(''); }}
              className="text-slate-505 hover:text-blue-600 transition font-semibold"
            >
              ← Back to gateway log
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
