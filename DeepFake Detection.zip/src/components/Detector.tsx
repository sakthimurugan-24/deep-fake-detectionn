/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  Film, 
  Music, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle,
  HelpCircle,
  Eye,
  Trash2,
  RefreshCw,
  Settings,
  Flame,
  Brain,
  Layers,
  HeartPulse,
  Download,
  Fingerprint
} from 'lucide-react';
import { AnalysisResult } from '../types';

interface DetectorProps {
  onAddHistoryItem: (report: AnalysisResult) => void;
  token: string | null;
  onOpenChatWithTopic: (topic: string) => void;
}

export default function Detector({
  onAddHistoryItem,
  token,
  onOpenChatWithTopic
}: DetectorProps) {
  // Input constraints
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [fileBase64, setFileBase64] = useState<string | null>(null);

  // Analysis State Engine
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [progressState, setProgressState] = useState<string>('');
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [currentResult, setCurrentResult] = useState<AnalysisResult | null>(null);
  const [hoveredHeatmapIndex, setHoveredHeatmapIndex] = useState<number | null>(null);
  const [errors, setErrors] = useState<string | null>(null);
  const [notif, setNotif] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Trigger Notifications / Toasts (Enterprise Light minimal)
  const triggerToast = (msg: string, type: 'success' | 'err' = 'success') => {
    setNotif(`${type === 'success' ? '✓' : '⚠️'} ${msg}`);
    setTimeout(() => setNotif(null), 4000);
  };

  // Convert files for payload proxying
  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFile = async (file: File) => {
    const validExtensions = ['png', 'jpg', 'jpeg', 'mp4', 'mov', 'wav', 'mp3'];
    const fileExt = file.name.split('.').pop()?.toLowerCase() || '';
    
    if (!validExtensions.includes(fileExt)) {
      setErrors(`Unsupported file format: .${fileExt}. DeepShield verifies standard image formats (.png/.jpg), videos (.mp4/.mov), or audio wave files (.wav/.mp3).`);
      return;
    }

    setErrors(null);
    setSelectedFile(file);
    
    // Create localized blob preview
    const previewUrl = URL.createObjectURL(file);
    setFilePreview(previewUrl);

    try {
      const base64Data = await convertFileToBase64(file);
      setFileBase64(base64Data);
      triggerToast('Media asset loaded into local secure sandbox.');
    } catch (err) {
      setErrors('Failed to parse media buffers.');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    setFilePreview(null);
    setFileBase64(null);
    setCurrentResult(null);
    setErrors(null);
  };

  // Execution algorithm
  const executeAnalysis = async () => {
    if (!selectedFile) return;
    
    setIsAnalyzing(true);
    setErrors(null);
    setProgressPercent(5);
    
    // Real-time progress indicators
    const stages = [
      { text: "Verifying digital signature hashes...", pct: 15 },
      { text: "Analyzing pixel-level wavelet spectra...", pct: 35 },
      { text: "Cross-referencing facial lighting angles...", pct: 60 },
      { text: "Executing convolutional GAN filter checks...", pct: 85 },
      { text: "Computing localized anomaly heatmaps...", pct: 98 }
    ];

    let currentStage = 0;
    const interval = setInterval(() => {
      if (currentStage < stages.length) {
        setProgressState(stages[currentStage].text);
        setProgressPercent(stages[currentStage].pct);
        currentStage++;
      } else {
        clearInterval(interval);
      }
    }, 450);

    try {
      await new Promise(resolve => setTimeout(resolve, 2500));

      const payload = {
        fileName: selectedFile.name,
        fileType: selectedFile.type || (selectedFile.name.endsWith('.mp4') ? 'video/mp4' : selectedFile.name.endsWith('.wav') ? 'audio/wav' : 'image/png'),
        fileSize: (selectedFile.size / (1024 * 1024)).toFixed(2) + " MB",
        fileBase64: fileBase64
      };

      const headers: any = {
        'Content-Type': 'application/json'
      };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers,
        body: JSON.stringify(payload)
      });

      const resData = await response.json();

      if (!response.ok) {
        throw new Error(resData.error || 'Server error during media inspection.');
      }

      setProgressPercent(100);
      setProgressState('Analysis complete.');
      
      setCurrentResult(resData);
      onAddHistoryItem(resData);
      triggerToast('Media authenticity verified.');
    } catch (err: any) {
      clearInterval(interval);
      setErrors(err?.message || 'Server timeout or API key threshold reached during analysis.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Export report
  const exportForensicLog = () => {
    if (!currentResult) return;
    const reportText = `
======================================================================
DEEPSHIELD AI - CRYPTOGRAPHIC FORENSIC MEDIA AUTHENTICITY REPORT
======================================================================
Report Reference GUID : ${currentResult.id}
Generated Timestamp   : ${currentResult.timestamp}
Target Asset Filename : ${currentResult.fileName}
Mime Payload Format   : ${currentResult.fileType}
Payload Binary Size   : ${currentResult.fileSize}
======================================================================
DETECTION METRICS METADATA:
----------------------------------------------------------------------
Classification        : ${currentResult.classification.toUpperCase()}
Deepfake Probability  : ${currentResult.fakeProbability}%
Analytical Confidence : ${currentResult.confidenceScore}%
======================================================================
`;
    const element = document.createElement("a");
    const file = new Blob([reportText], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `DeepShield_Report_${currentResult.id.substring(0,8)}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    triggerToast('Forensic report downloaded successfully.');
  };

  return (
    <div id="detector-module" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left text-slate-800 space-y-8">
      
      {/* Toast Alert Indicator */}
      {notif && (
        <div className="fixed top-20 right-4 z-50 rounded-lg border border-slate-200 bg-white py-3 px-5 text-xs text-slate-900 font-semibold shadow-md animate-slide-in">
          {notif}
        </div>
      )}

      {/* Grid Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Upload Area & Targets */}
        <div className="lg:col-span-6 space-y-6">
          <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm relative">
            <h2 className="text-lg font-bold tracking-tight text-slate-900 mb-1 flex items-center gap-2">
              <Upload className="h-5 w-5 text-blue-600" />
              Ingestion Terminal
            </h2>
            <p className="text-xs text-slate-500 mb-6">
              SaaS-encrypted file drops are sandboxed locally. Data is processed ephemerally.
            </p>

            {errors && (
              <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-xs font-semibold text-red-700 mb-4 leading-relaxed">
                ⚠️ {errors}
              </div>
            )}

            {!filePreview ? (
              /* Drag Drop Container */
              <div
                id="drop-zone"
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-lg p-10 text-center transition cursor-pointer flex flex-col items-center justify-center space-y-4 ${
                  dragActive 
                    ? 'border-blue-550 bg-blue-50/50' 
                    : 'border-slate-300 bg-slate-50/50 hover:border-blue-400 hover:bg-slate-50'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  onChange={handleFileChange}
                  accept=".png,.jpg,.jpeg,.mp4,.mov,.wav,.mp3"
                />
                
                <div className="h-12 w-12 rounded-full border border-slate-250 bg-white text-slate-600 flex items-center justify-center shadow-sm">
                  <Upload className="h-5 w-5 text-blue-600" />
                </div>

                <div className="space-y-1">
                  <p className="text-sm font-semibold text-slate-800">
                    Drag and drop file here, or <span className="text-blue-600 underline">browse</span>
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Supports PNG, JPG, MP4, MOV, WAV, or MP3 (Max 50MB)
                  </p>
                </div>
              </div>
            ) : (
              /* Active upload state with rich component mockup styling */
              <div className="space-y-4">
                <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5 flex items-center justify-between">
                  <div className="flex items-center space-x-3 overflow-hidden">
                    <div className="h-9 w-9 rounded bg-white border border-slate-200 text-slate-500 flex items-center justify-center shrink-0">
                      {selectedFile?.type.startsWith('video/') ? (
                        <Film className="h-4.5 w-4.5 text-blue-600" />
                      ) : selectedFile?.type.startsWith('audio/') ? (
                        <Music className="h-4.5 w-4.5 text-blue-600" />
                      ) : (
                        <ImageIcon className="h-4.5 w-4.5 text-blue-600" />
                      )}
                    </div>
                    <div className="text-left overflow-hidden">
                      <p className="text-xs font-semibold text-slate-800 truncate">{selectedFile?.name}</p>
                      <p className="text-[10px] text-slate-500">{(selectedFile!.size / (1024 * 1024)).toFixed(2)} MB • {selectedFile?.type || 'Media payload'}</p>
                    </div>
                  </div>
                  <button
                    onClick={handleReset}
                    className="p-1.5 rounded-md hover:bg-red-50 hover:text-red-600 text-slate-400 border border-slate-200 transition"
                    title="Remove file"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>

                {/* Media Preview container */}
                <div className="rounded-lg border border-slate-200 bg-slate-50/50 overflow-hidden relative max-h-[350px] flex items-center justify-center p-2">
                  {selectedFile?.type.startsWith('image/') && (
                    <div className="relative w-full h-full flex items-center justify-center">
                      <img 
                        src={filePreview} 
                        alt="Audited media payload" 
                        className="max-h-[300px] object-contain rounded select-none shadow-sm"
                      />
                      
                      {/* Localized deepfake heat circles */}
                      {currentResult && currentResult.heatmap && currentResult.heatmap.map((pt, index) => (
                        <div
                          key={index}
                          className="absolute border-2 border-dashed border-red-500 rounded-full cursor-pointer flex items-center justify-center shadow-sm"
                          style={{
                            left: `${pt.x}%`,
                            top: `${pt.y}%`,
                            width: `${pt.radius * 1.5}px`,
                            height: `${pt.radius * 1.5}px`,
                            transform: 'translate(-50%, -50%)'
                          }}
                          onMouseEnter={() => setHoveredHeatmapIndex(index)}
                          onMouseLeave={() => setHoveredHeatmapIndex(null)}
                        >
                          <div className="w-2.5 h-2.5 rounded-full bg-red-650" />
                          
                          {/* Label tooltip */}
                          {hoveredHeatmapIndex === index && (
                            <div className="absolute top-[110%] bg-slate-900 text-white font-mono text-[10px] px-2 py-1 rounded shadow-md z-30 pointer-events-none whitespace-nowrap">
                              <span className="font-bold text-red-400 block tracking-wide">ANOMALY #{index + 1}</span>
                              {pt.label}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {selectedFile?.type.startsWith('video/') && (
                    <video 
                      src={filePreview} 
                      controls 
                      className="w-full max-h-[300px] object-contain rounded"
                    />
                  )}

                  {selectedFile?.type.startsWith('audio/') && (
                    <div className="w-full py-10 px-4 flex flex-col items-center justify-center space-y-4">
                      <div className="h-10 w-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shadow-sm">
                        <Music className="h-5 w-5" />
                      </div>
                      <audio src={filePreview} controls className="w-full max-w-sm" />
                    </div>
                  )}
                </div>

                {/* Submit trigger buttons */}
                {!currentResult && !isAnalyzing && (
                  <button
                    onClick={executeAnalysis}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs tracking-wider uppercase rounded-lg transition-colors shadow-sm cursor-pointer"
                  >
                    Execute Forensic AI Scan
                  </button>
                )}

                {/* In progress analytics banner */}
                {isAnalyzing && (
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 space-y-3">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-700 font-semibold">{progressState}</span>
                      <span className="text-blue-600 font-extrabold">{progressPercent}%</span>
                    </div>
                    <div className="w-full bg-slate-250 h-2 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-600 transition-all duration-300" 
                        style={{ width: `${progressPercent}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Deep Analysis Outcomes */}
        <div id="outcomes-terminal" className="lg:col-span-6">
          {!currentResult ? (
            /* Standby State */
            <div className="rounded-xl border border-slate-200 bg-white p-12 text-center h-full flex flex-col items-center justify-center space-y-5 shadow-sm">
              <div className="h-12 w-12 rounded-lg bg-slate-50 text-slate-450 border border-slate-150 flex items-center justify-center">
                <Settings className="h-5.5 w-5.5 text-slate-400" />
              </div>
              <div className="max-w-md space-y-2">
                <h3 className="text-sm font-bold text-slate-800">Awaiting Media Payload</h3>
                <p className="text-xs text-slate-500 leading-relaxed font-light">
                  Upload an image, audio clip, or video wrap to initiate algorithmic checks. Results highlight high-frequency residual noise bands, spatial facial vector imbalances, and resonance spectrogram patterns.
                </p>
              </div>
              <div className="pt-2 flex flex-wrap items-center justify-center gap-2 text-[10px] text-slate-500 font-mono">
                <span className="border border-slate-200 px-2 py-0.5 rounded bg-slate-50">Image Wavelets</span>
                <span className="border border-slate-200 px-2 py-0.5 rounded bg-slate-50">Vocal Biometrics</span>
                <span className="border border-slate-200 px-2 py-0.5 rounded bg-slate-50">Light Vectors</span>
              </div>
            </div>
          ) : (
            /* Active Outcomes */
            <div className="space-y-6 animate-fade-in">
              <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm space-y-6">
                
                {/* Visual Verdict Banner */}
                <div className="flex items-center justify-between border-b border-slate-150 pb-4">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold block">Consensus Classification</span>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2.5 py-0.5 text-xs font-bold rounded-md ${
                        currentResult.classification === 'Real' 
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-250'
                          : currentResult.classification === 'Suspicious'
                            ? 'bg-amber-50 text-amber-700 border border-amber-250'
                            : 'bg-red-50 text-red-700 border border-red-250'
                      }`}>
                        {currentResult.classification}
                      </span>
                      <Fingerprint className={`h-4 w-4 ${
                        currentResult.classification === 'Real' ? 'text-emerald-600' : 'text-red-600'
                      }`} />
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <button
                      onClick={exportForensicLog}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 cursor-pointer shadow-sm"
                      title="Export Forensic Text Report"
                    >
                      <Download className="h-3.5 w-3.5" /> Export Report
                    </button>
                    <button
                      onClick={handleReset}
                      className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-500 cursor-pointer shadow-sm"
                      title="Run new scan"
                    >
                      <RefreshCw className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                {/* Score meters */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="border border-slate-200 p-4 rounded-xl text-center shadow-sm bg-slate-50/50">
                    <span className="text-[10px] tracking-wider text-slate-500 uppercase font-bold">Synthesized Index Probability</span>
                    <div className="mt-2 text-3xl font-bold text-red-600 tracking-tight">{currentResult.fakeProbability}%</div>
                    <div className="w-full bg-slate-200 h-1 rounded-full mt-2 overflow-hidden">
                      <div className="h-full bg-red-500" style={{ width: `${currentResult.fakeProbability}%` }} />
                    </div>
                  </div>

                  <div className="border border-slate-200 p-4 rounded-xl text-center shadow-sm bg-slate-50/50">
                    <span className="text-[10px] tracking-wider text-slate-500 uppercase font-bold">Analytical Confidence</span>
                    <div className="mt-2 text-3xl font-bold text-blue-600 tracking-tight">{currentResult.confidenceScore}%</div>
                    <div className="w-full bg-slate-200 h-1 rounded-full mt-2 overflow-hidden">
                      <div className="h-full bg-blue-600" style={{ width: `${currentResult.confidenceScore}%` }} />
                    </div>
                  </div>
                </div>

                {/* Bullet point lists */}
                <div className="space-y-2 text-left">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <Layers className="h-3.5 w-3.5 text-blue-600" /> Isolated Forensic Artifact Logs
                  </h4>
                  <ul className="space-y-2 border-t border-slate-100 pt-3 text-xs text-slate-600">
                    {currentResult.evidence.map((point, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-blue-600 mt-0.5 shrink-0">■</span>
                        <span className="font-light leading-relaxed">{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Deep sub-analyses */}
                <div className="space-y-2.5 pt-2 text-left">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <Brain className="h-3.5 w-3.5 text-blue-600" /> Neural Sub-Focal Analysis
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px] leading-relaxed text-slate-500 pt-1.5">
                    <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-800 block mb-1">Noise Spectrograph Wavelet</span>
                      {currentResult.sections.noiseAnalysis}
                    </div>
                    <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-800 block mb-1">Interfacial Light Alignment</span>
                      {currentResult.sections.lightingAnalysis}
                    </div>
                    <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-800 block mb-1">Geometric Grid Warps</span>
                      {currentResult.sections.geometricInconsistency}
                    </div>
                    <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200">
                      <span className="text-[10px] font-bold text-slate-800 block mb-1">Pixel Spectrograph anomalies</span>
                      {currentResult.sections.facialFrequencyAnomalies}
                    </div>
                  </div>
                </div>

                {/* Copilot assistance call Box */}
                <div className="rounded-lg border border-dashed border-blue-200 bg-blue-50/30 p-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
                  <p className="text-slate-600 text-center sm:text-left leading-relaxed font-light">
                    Have questions regarding these anomalous patterns or local GAN mappings?
                  </p>
                  <button
                    onClick={() => onOpenChatWithTopic(`Review the forensic results representing audit target report id ${currentResult.id}. Classification: ${currentResult.classification} is flagged with fake indices at ${currentResult.fakeProbability}%.`)}
                    className="shrink-0 bg-blue-600 text-white hover:bg-blue-700 py-1.5 px-3.5 rounded font-semibold transition cursor-pointer text-[11px]"
                  >
                    Discuss with Copilot AI
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
