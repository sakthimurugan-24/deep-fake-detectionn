/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Send, X, Bot, Shield, MessagesSquare, CornerDownLeft, Sparkles, AlertTriangle } from 'lucide-react';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
}

interface ChatbotProps {
  onClose: () => void;
  initialTopic?: string;
}

export default function Chatbot({
  onClose,
  initialTopic
}: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'bot',
      text: "Specialist, welcome to the real-time Forensic Copilot interface. How can I assist you with GAN wavelet calculations, biometric voice spectrograms, or spatial anomaly verification?",
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll helper
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Handle starter click
  const executeMessageRequest = async (text: string) => {
    if (!text.trim()) return;
    
    const userMsg: Message = {
      id: "us-" + Math.random().toString(36).substring(2, 6),
      sender: 'user',
      text,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    try {
      // Proxy prompt query through node backend router for Gemini API integration
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: text })
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Server error.');
      }

      const botMsg: Message = {
        id: "bt-" + Math.random().toString(36).substring(2, 6),
        sender: 'bot',
        text: data.reply,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);

    } catch (err: any) {
      // Beautiful local fallback response in matching style
      const botMsg: Message = {
        id: "bt-err-" + Math.random().toString(36).substring(2, 6),
        sender: 'bot',
        text: "I detected a connection timeout while querying the model cluster, but here's a forensic analysis summary: GAN textures typically exhibit geometric noise residue at high-frequency wavebands. Let me know if you would like me to detail further forensic parameters.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    const prompt = inputText;
    setInputText('');
    executeMessageRequest(prompt);
  };

  // Triggered topic injection on mount
  useEffect(() => {
    if (initialTopic) {
      executeMessageRequest(initialTopic);
    }
  }, [initialTopic]);

  return (
    <div 
      id="chatbot-drawer" 
      className="fixed top-[65px] right-0 bottom-0 z-40 w-full sm:w-[400px] bg-white border-l border-slate-200 shadow-xl flex flex-col justify-between animate-slide-in text-left text-slate-800"
    >
      
      {/* Drawer Header */}
      <div className="px-4 py-3.5 border-b border-slate-150 flex items-center justify-between bg-slate-50">
        <div className="flex items-center space-x-2">
          <div className="h-2 w-2 rounded-full bg-blue-600 animate-pulse" />
          <Bot className="h-4 w-4 text-blue-600" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-800">Forensic Copilot AI</span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded hover:bg-slate-200/80 text-slate-450 transition cursor-pointer"
          title="Minimize sidebar panel"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Messages area list */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
        {messages.map((m) => (
          <div 
            key={m.id} 
            className={`flex flex-col max-w-[85%] ${
              m.sender === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'
            }`}
          >
            <div className={`p-3 rounded-lg text-xs leading-relaxed ${
              m.sender === 'user'
                ? 'bg-slate-100 border border-slate-200 text-slate-800'
                : 'bg-blue-50/50 border border-blue-100 text-slate-900'
            }`}>
              {m.text}
            </div>
            <span className="text-[9px] text-slate-400 mt-1 font-mono">
              {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        ))}

        {isTyping && (
          <div className="mr-auto max-w-[85%] flex flex-col items-start">
            <div className="bg-blue-50/30 border border-blue-100 p-3 rounded-lg text-xs text-slate-650 flex items-center space-x-2">
              <span className="h-1.5 w-1.5 rounded-full bg-blue-600 animate-bounce" />
              <span className="h-1.5 w-1.5 rounded-full bg-blue-600 animate-bounce delay-75" />
              <span className="h-1.5 w-1.5 rounded-full bg-blue-600 animate-bounce delay-150" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Prompt Starters */}
      <div className="px-4 py-2 bg-slate-50/55 border-t border-slate-150 space-y-2">
        <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest block">SUGGESTED DISCUSSIONS:</span>
        <div className="flex flex-wrap gap-1.5 pt-1">
          <button
            onClick={() => executeMessageRequest("How are pixel wavelets calculated under convolutional GAN noise analysis?")}
            className="text-[9px] bg-white border border-slate-200 hover:border-blue-400 text-slate-600 hover:text-blue-600 font-semibold py-1 px-2.5 rounded transition cursor-pointer"
          >
            How Wavelets Work
          </button>
          <button
            onClick={() => executeMessageRequest("Explain how deepfakes show temporal light alignment discrepancies.")}
            className="text-[9px] bg-white border border-slate-200 hover:border-blue-400 text-slate-600 hover:text-blue-600 font-semibold py-1 px-2.5 rounded transition cursor-pointer"
          >
            Lighting Anomaly Details
          </button>
        </div>
      </div>

      {/* Message input field bar */}
      <form onSubmit={handleSend} className="p-3 border-t border-slate-150 bg-white">
        <div className="relative rounded-lg border border-slate-250 bg-white focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition duration-150 flex items-center">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Query forensic algorithms..."
            className="block w-full py-2.5 pl-3 pr-10 text-xs text-slate-800 placeholder-slate-400 bg-transparent border-0 focus:outline-none focus:ring-0"
          />
          <button
            type="submit"
            className="absolute right-1.5 p-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 transition cursor-pointer"
            title="Submit query"
          >
            <Send className="h-3 w-3" />
          </button>
        </div>
      </form>

    </div>
  );
}
