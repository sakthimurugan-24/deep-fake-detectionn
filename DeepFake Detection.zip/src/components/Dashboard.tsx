/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Search, 
  Filter, 
  Trash2, 
  TrendingUp, 
  Calendar, 
  Compass, 
  User as UserIcon, 
  Download, 
  Layers, 
  Cpu, 
  RotateCw,
  RefreshCcw,
  CheckCircle,
  AlertTriangle,
  XSquare,
  Shield,
  FileText,
  Clock,
  ExternalLink
} from 'lucide-react';
import { User, AnalysisResult } from '../types';

interface DashboardProps {
  currentUser: User | null;
  history: AnalysisResult[];
  onDeleteReport: (id: string) => void;
  token: string | null;
  setCurrentTab: (tab: string) => void;
  onRefreshData: () => void;
}

export default function Dashboard({
  currentUser,
  history,
  onDeleteReport,
  token,
  setCurrentTab,
  onRefreshData
}: DashboardProps) {
  // Query state elements
  const [searchQuery, setSearchQuery] = useState('');
  const [filterClass, setFilterClass] = useState<'all' | 'Real' | 'Suspicious' | 'Deepfake'>('all');
  const [stats, setStats] = useState({
    total: 0,
    fakes: 0,
    suspicious: 0,
    real: 0,
    averageConfidence: 100,
    percentFake: 0
  });

  const [notif, setNotif] = useState<string | null>(null);

  useEffect(() => {
    // Generate derived statistics locally from history
    const total = history.length;
    const fakes = history.filter(h => h.classification === 'Deepfake').length;
    const suspicious = history.filter(h => h.classification === 'Suspicious').length;
    const real = history.filter(h => h.classification === 'Real').length;
    
    const averageConfidence = total 
      ? Number((history.reduce((sum, h) => sum + h.confidenceScore, 0) / total).toFixed(1)) 
      : 105;
    
    const percentFake = total ? Number(((fakes / total) * 100).toFixed(1)) : 0;

    setStats({
      total,
      fakes,
      suspicious,
      real,
      averageConfidence: averageConfidence > 100 ? 100 : averageConfidence,
      percentFake
    });
  }, [history]);

  // Handle report downloading
  const triggerReportDownload = (report: AnalysisResult) => {
    const logStr = `
DEEPSHIELD AI - CRYPTOGRAPHIC FORENSIC MEDIA ANALYSIS VERDICT LOG
------------------------------------------------------------------
Report GUID  : ${report.id}
File Target  : ${report.fileName}
Mime Payload : ${report.fileType}
Audit Date   : ${report.timestamp}
Verdict      : ${report.classification.toUpperCase()}
Fake Index   : ${report.fakeProbability}%
Confidence   : ${report.confidenceScore}%

Key Anomalous Indices Identified:
${report.evidence.map((p, i) => `  (${i + 1}) ${p}`).join('\n')}

System classification mapped securely to local node keys.
`;
    const element = document.createElement("a");
    const file = new Blob([logStr], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `DeepShield_Forensic_${report.id.substring(0,8)}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    
    setNotif('✓ Diagnostic report exported.');
    setTimeout(() => setNotif(null), 3000);
  };

  // Delete callback
  const handleItemDelete = async (id: string) => {
    if (confirm('Deactivating and purging this asset report permanently. Confirm?')) {
      onDeleteReport(id);
      setNotif('✓ Media report successfully purged.');
      setTimeout(() => setNotif(null), 3500);
    }
  };

  // Filters & Search
  const filteredHistory = history.filter(item => {
    const matchSearch = item.fileName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchFilter = filterClass === 'all' || item.classification === filterClass;
    return matchSearch && matchFilter;
  });

  return (
    <div id="dashboard-portal" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left text-slate-800 space-y-6">
      
      {/* Toast Alert Banner */}
      {notif && (
        <div className="fixed top-20 right-4 z-50 rounded-lg border border-slate-200 bg-white py-3 px-5 text-xs text-slate-800 font-semibold shadow-md animate-slide-in">
          {notif}
        </div>
      )}

      {/* Corporate Dashboard Top Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Forensic Control Console
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Assigned Specialist: <span className="text-slate-800 font-semibold">{currentUser?.name || 'Authorized Specialist'}</span> • Key Security Level: <span className="text-blue-600 font-mono font-bold uppercase">{currentUser?.role || 'Staff'}</span>
          </p>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={() => setCurrentTab('detection')}
            className="rounded-lg bg-blue-600 hover:bg-blue-700 px-4 py-2 text-xs font-semibold text-white shadow-sm transition"
          >
            + New Diagnostic Scan
          </button>
          
          <button
            onClick={onRefreshData}
            className="p-2 border border-slate-200 bg-white hover:bg-slate-50 rounded-lg text-slate-500 hover:text-slate-800 transition shadow-sm"
            title="Refresh database records"
          >
            <RefreshCcw className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Corporate Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total Scans Executed</span>
          <div className="mt-2.5 text-2xl font-bold text-slate-900">{stats.total}</div>
          <p className="text-[10px] text-slate-500 mt-1">Platform aggregated total</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Deepfakes Isolated</span>
          <div className="mt-2.5 text-2xl font-bold text-red-600">{stats.fakes}</div>
          <p className="text-[10px] text-red-650 mt-1">{stats.percentFake}% malicious synthetic ratio</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Suspicious / Pending</span>
          <div className="mt-2.5 text-2xl font-bold text-amber-600">{stats.suspicious}</div>
          <p className="text-[10px] text-slate-500 mt-1">Requires manual visual audit</p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Average Trust level</span>
          <div className="mt-2.5 text-2xl font-bold text-emerald-600">{stats.averageConfidence}%</div>
          <p className="text-[10px] text-slate-500 mt-1">Average detection accuracy score</p>
        </div>
      </div>

      {/* Enterprise SaaS Sidebar Nav / Overview Column Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: sidebar navigation, status index, risk gauge graph (Requirement 9) */}
        <div id="analytics-column" className="lg:col-span-4 space-y-6">
          
          {/* Quick Navigation Sidebar (SaaS-like structural widget) */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm space-y-1">
            <h3 className="text-[10px] uppercase font-bold text-slate-400 px-3 mb-2 tracking-widest">Platform Services</h3>
            <button 
              onClick={() => setCurrentTab('home')}
              className="w-full flex items-center justify-between text-left px-3 py-2 text-xs font-semibold rounded-lg text-slate-650 hover:bg-slate-50 transition"
            >
              <span>Platform Overview Page</span>
              <Compass className="h-4 w-4 text-slate-400" />
            </button>
            <button 
              onClick={() => setCurrentTab('detection')}
              className="w-full flex items-center justify-between text-left px-3 py-2 text-xs font-semibold rounded-lg text-slate-650 hover:bg-slate-50 transition"
            >
              <span>Deploy Forensic Scanner</span>
              <Layers className="h-4 w-4 text-slate-400" />
            </button>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm space-y-6 text-left">
            <h2 className="text-xs font-bold tracking-widest text-slate-450 uppercase flex items-center gap-1.5 border-b border-slate-100 pb-3">
              <BarChart3 className="h-4 w-4 text-blue-600" /> Risk Assessment
            </h2>
            
            {stats.total === 0 ? (
              <div className="py-10 text-center text-xs text-slate-500">
                No telemetry data available. Scan a file to generate risk charts.
              </div>
            ) : (
              <div className="space-y-6">
                
                {/* Custom SVG gauge list representing professional design (Requirement 13) */}
                <div className="flex justify-center items-center py-2 relative">
                  <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="40" fill="transparent" stroke="#F1F5F9" strokeWidth="8" />
                    
                    {/* Real */}
                    <circle 
                      cx="50" 
                      cy="50" 
                      r="40" 
                      fill="transparent" 
                      stroke="#10B981" 
                      strokeWidth="8" 
                      strokeDasharray={`${(stats.real / stats.total) * 251.2} 251.2`}
                    />

                    {/* Suspicious */}
                    <circle 
                      cx="50" 
                      cy="50" 
                      r="40" 
                      fill="transparent" 
                      stroke="#F59E0B" 
                      strokeWidth="8" 
                      strokeDasharray={`${(stats.suspicious / stats.total) * 251.2} 251.2`}
                      strokeDashoffset={`-${(stats.real / stats.total) * 251.2}`}
                    />

                    {/* Deepfake */}
                    <circle 
                      cx="50" 
                      cy="50" 
                      r="40" 
                      fill="transparent" 
                      stroke="#EF4444" 
                      strokeWidth="8" 
                      strokeDasharray={`${(stats.fakes / stats.total) * 251.2} 251.2`}
                      strokeDashoffset={`-${((stats.real + stats.suspicious) / stats.total) * 251.2}`}
                    />
                  </svg>
                  
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className="text-xl font-bold text-slate-800">{stats.total}</span>
                    <span className="text-[9px] text-slate-400 uppercase tracking-widest font-semibold font-mono">Audits</span>
                  </div>
                </div>

                {/* Legend list */}
                <div className="space-y-2 border-t border-slate-100 pt-4">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded bg-emerald-500" />
                      <span className="text-slate-500">Real Media</span>
                    </div>
                    <span className="font-bold text-slate-800">{stats.real} ({stats.total ? Math.round((stats.real / stats.total) * 100) : 0}%)</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded bg-amber-500" />
                      <span className="text-slate-500">Suspicious</span>
                    </div>
                    <span className="font-bold text-slate-800">{stats.suspicious} ({stats.total ? Math.round((stats.suspicious / stats.total) * 100) : 0}%)</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded bg-red-500" />
                      <span className="text-slate-500">Deepfake Detected</span>
                    </div>
                    <span className="font-bold text-slate-800">{stats.fakes} ({stats.total ? Math.round((stats.fakes / stats.total) * 100) : 0}%)</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: History Scans list & activity timeline */}
        <div id="logs-column" className="lg:col-span-8 space-y-4">
          
          {/* Action filters */}
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
            {/* Search */}
            <div className="relative w-full sm:max-w-xs rounded-lg border border-slate-200 bg-white focus-within:border-blue-500 focus-within:ring-1 focus-within:ring-blue-500 transition duration-150 shrink-0 shadow-sm">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-450 pointer-events-none">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search report file names..."
                className="block w-full py-2 pl-9 pr-3 text-xs text-slate-800 placeholder-slate-400 bg-transparent border-0 focus:outline-none focus:ring-0"
              />
            </div>

            {/* Filter class buttons */}
            <div className="flex items-center space-x-1 shrink-0 bg-slate-100 p-1 rounded-lg border border-slate-200">
              {(['all', 'Real', 'Suspicious', 'Deepfake'] as const).map(option => (
                <button
                  key={option}
                  onClick={() => setFilterClass(option)}
                  className={`px-3 py-1.5 rounded-md text-[10px] font-bold uppercase tracking-wider transition ${
                    filterClass === option 
                      ? 'bg-white text-blue-600 shadow-sm border-slate-100' 
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>

          {/* Central scans table list */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm overflow-hidden text-left">
            <h2 className="text-xs font-bold tracking-widest text-slate-450 uppercase mb-5 flex items-center gap-1.5">
              <Layers className="h-4 w-4 text-blue-600" /> Target Forensic Log History
            </h2>

            {filteredHistory.length === 0 ? (
              <div className="py-14 text-center text-xs text-slate-500 font-light">
                {searchQuery || filterClass !== 'all' 
                  ? 'No diagnostic records fit the searched query filters.' 
                  : 'Platform history is blank. Start by uploading a media packet.'}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredHistory.map((item) => (
                  <div 
                    key={item.id} 
                    className="p-4 rounded-lg border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-blue-400 transition"
                  >
                    <div className="text-left space-y-1 overflow-hidden">
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-widest border ${
                          item.classification === 'Real' 
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : item.classification === 'Suspicious'
                              ? 'bg-amber-50 text-amber-700 border-amber-200'
                              : 'bg-red-50 text-red-700 border-red-200'
                        }`}>
                          {item.classification}
                        </span>
                        <span className="text-xs font-bold text-slate-800 truncate max-w-xs">{item.fileName}</span>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 font-mono text-[9px] text-slate-400">
                        <span>Format: {item.fileType}</span>
                        <span>Size: {item.fileSize}</span>
                        <span>Risk score: <strong className="text-red-500 font-bold">{item.fakeProbability}%</strong></span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(item.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <button
                        onClick={() => triggerReportDownload(item)}
                        className="p-1.5 rounded-lg bg-white hover:bg-slate-50 text-slate-550 border border-slate-200 hover:border-slate-350 transition shadow-sm cursor-pointer"
                        title="Download forensic text report"
                      >
                        <Download className="h-4 w-4 text-blue-600" />
                      </button>
                      <button
                        onClick={() => handleItemDelete(item.id)}
                        className="p-1.5 rounded-lg bg-white hover:bg-red-50 hover:text-red-650 hover:border-red-200 text-slate-450 border border-slate-200 transition shadow-sm cursor-pointer"
                        title="Purge record"
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
