/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Users, 
  Trash2, 
  ShieldAlert as AlertIcon, 
  Terminal, 
  Activity, 
  Play, 
  Settings, 
  Settings2,
  RefreshCcw,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Network
} from 'lucide-react';
import { ModelStatus, SystemLog, User } from '../types';
import { INITIAL_AI_MODELS, INITIAL_SYSTEM_LOGS } from '../data/mockModelStats';

interface AdminPanelProps {
  token: string | null;
}

export default function AdminPanel({
  token
}: AdminPanelProps) {
  // Local admin structures
  const [users, setUsers] = useState<User[]>([]);
  const [models, setModels] = useState<ModelStatus[]>(INITIAL_AI_MODELS);
  const [logs, setLogs] = useState<SystemLog[]>(INITIAL_SYSTEM_LOGS);
  
  const [loadingUsers, setLoadingUsers] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notif, setNotif] = useState<string | null>(null);

  // Trigger Notifications / Toasts
  const triggerToast = (msg: string, type: 'success' | 'err' = 'success') => {
    setNotif(`${type === 'success' ? '✓' : '⚠️'} ${msg}`);
    setTimeout(() => setNotif(null), 3000);
  };

  const fetchUsers = async () => {
    if (!token) return;
    setLoadingUsers(true);
    setError(null);
    try {
      const response = await fetch('/api/admin/users', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Server error loading users list.');
      }
      setUsers(data);
    } catch (err: any) {
      setError(err?.message || 'Access blocked. Make sure session possesses admin credentials.');
    } finally {
      setLoadingUsers(false);
    }
  };

  // Toggle user roles
  const handleToggleUserRole = async (userId: string, currentRole: 'admin' | 'user') => {
    if (!token) return;
    const targetRole = currentRole === 'admin' ? 'user' : 'admin';
    try {
      const response = await fetch(`/api/admin/users/${userId}/role`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ role: targetRole })
      });
      const resData = await response.json();
      if (!response.ok) {
        throw new Error(resData.error || 'Failed to update user role.');
      }
      
      triggerToast(`User role updated successfully.`);
      fetchUsers(); // Refresh
      
      // Log Action in System logs
      const shadowLog: SystemLog = {
        id: "log-" + Math.random().toString(36).substring(2, 6),
        timestamp: "Now",
        service: "Security Auth Engine",
        level: "warn",
        message: `Admin modified clearance levels of ID ${userId} to ${targetRole}.`
      };
      setLogs(l => [shadowLog, ...l]);
    } catch (err: any) {
      triggerToast(err?.message || 'Failed to adjust role.', 'err');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!token) return;
    if (userId === 'usr-admin') {
      triggerToast('Security constraint: Root administrator cannot be purged.', 'err');
      return;
    }
    if (!confirm('Permanent deactivation of user credential records requested. Proceed?')) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const resData = await response.json();
      if (!response.ok) {
        throw new Error(resData.error || 'Failed to purge user.');
      }
      triggerToast('User account successfully deactivated.');
      fetchUsers();
      
      const shadowLog: SystemLog = {
        id: "log-" + Math.random().toString(36).substring(2, 6),
        timestamp: "Now",
        service: "Security Auth Engine",
        level: "error",
        message: `Purged identity credentials pointing to user ID ${userId}.`
      };
      setLogs(l => [shadowLog, ...l]);
    } catch (err: any) {
      triggerToast(err?.message || 'Purging failed.', 'err');
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [token]);

  return (
    <div id="admin-hq-view" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left text-slate-800 space-y-6 animate-fade-in">
      
      {/* Toast Alert Banner */}
      {notif && (
        <div className="fixed top-20 right-4 z-50 rounded-lg border border-slate-200 bg-white py-3 px-5 text-xs text-slate-800 font-semibold shadow-md animate-slide-in">
          {notif}
        </div>
      )}

      {/* Corporate Admin Header bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Security Control Headquarters
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Central orchestration of synthetic media classifiers, staff parameters, and secure auditing streams.
          </p>
        </div>
        
        <button
          onClick={fetchUsers}
          className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 px-3.5 py-2 text-xs font-semibold text-slate-700 transition shadow-sm cursor-pointer"
        >
          <RefreshCcw className="h-4 w-4 text-blue-600" /> Sync Staff Registry
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-xs font-semibold text-red-700 mb-4 tracking-wide leading-relaxed">
          ⚠️ {error} <br />
          <span className="text-[10px] text-slate-500 font-light mt-1.5 block">
            Access denied. Make sure you are logged into an authorized admin account credentials (e.g. <strong>admin@deepshield.ai</strong>).
          </span>
        </div>
      )}

      {/* Grid view */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Manage users, model status */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Staff list panel table */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm text-left">
            <h2 className="text-xs font-bold tracking-widest text-slate-450 uppercase mb-5 flex items-center gap-1.5">
              <Users className="h-4 w-4 text-blue-600" /> Authorized Staff Clearance Registry
            </h2>

            {loadingUsers ? (
              <div className="py-14 text-center text-xs text-slate-500 font-mono">
                <span className="animate-spin inline-block h-3.5 w-3.5 border-2 border-blue-650 border-t-transparent rounded-full mr-2" />
                Retrieving registry database records...
              </div>
            ) : users.length === 0 ? (
              <div className="py-14 text-center text-xs text-slate-500 font-light">
                Registry records offline. Authenticate with an admin account vector to access details.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead>
                    <tr className="border-b border-slate-150 text-slate-500 uppercase tracking-wider text-[10px] font-bold">
                      <th className="pb-3 pr-2">Specialist Name</th>
                      <th className="pb-3 pr-2">Security Mail ID</th>
                      <th className="pb-3 pr-2 text-center">Clearance Status</th>
                      <th className="pb-3 text-right">Revoke</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {users.map(u => (
                      <tr key={u.id} className="hover:bg-slate-50/50 transition">
                        <td className="py-3.5 font-semibold text-slate-900">{u.name}</td>
                        <td className="py-3.5 font-mono text-slate-500">{u.email}</td>
                        <td className="py-3.5 text-center">
                          <button
                            onClick={() => handleToggleUserRole(u.id, u.role)}
                            className={`px-2.5 py-0.5 rounded text-[10px] font-bold font-mono uppercase tracking-wider transition cursor-pointer ${
                              u.role === 'admin' 
                                ? 'bg-purple-50 text-purple-700 border border-purple-200' 
                                : 'bg-slate-100 text-slate-600 border border-slate-200'
                            }`}
                          >
                            {u.role}
                          </button>
                        </td>
                        <td className="py-3.5 text-right">
                          <button
                            onClick={() => handleDeleteUser(u.id)}
                            className="p-1.5 rounded-lg hover:bg-red-50 hover:text-red-650 text-slate-400 hover:border-red-200 border border-slate-200 transition"
                            title="Deactivate account credential stream"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* AI models status matrix */}
          <div className="rounded-xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm space-y-5 text-left">
            <h2 className="text-xs font-bold tracking-widest text-slate-450 uppercase flex items-center gap-1.5">
              <Network className="h-4 w-4 text-blue-600" /> AI classifier cluster status
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {models.map((mod, index) => (
                <div key={index} className="rounded-lg border border-slate-200 bg-slate-50/50 p-4 space-y-3 relative shadow-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">{mod.name}</span>
                    <span className="px-2 py-0.5 rounded text-[8px] font-bold font-mono bg-emerald-50 text-emerald-700 border border-emerald-250">
                      {mod.status}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-1.5 font-mono text-[9px] text-slate-450 text-left border-t border-slate-100 pt-2.5">
                    <div>
                      <span className="block text-slate-500 font-bold uppercase text-[7px] tracking-wide mb-1">Version</span>
                      {mod.version}
                    </div>
                    <div>
                      <span className="block text-slate-500 font-bold uppercase text-[7px] tracking-wide mb-1">Latency</span>
                      {mod.latency}
                    </div>
                    <div>
                      <span className="block text-slate-500 font-bold uppercase text-[7px] tracking-wide mb-1">Accuracy</span>
                      <strong className="text-blue-605">{mod.accuracy}</strong>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Systems active CLI status logs */}
        <div id="telemetry-logs-column" className="lg:col-span-5 space-y-6">
          <div className="rounded-xl border border-slate-200 bg-white p-5 sm:p-6 shadow-sm h-full flex flex-col justify-between text-left">
            <div className="space-y-4">
              <h2 className="text-xs font-bold tracking-widest text-slate-450 uppercase flex items-center gap-1.5">
                <Terminal className="h-4 w-4 text-blue-600" /> Event Telemetry Stream
              </h2>

              <div className="font-mono text-[10px] text-slate-400 bg-slate-900 border border-slate-950 p-4 rounded-lg space-y-3.5 max-h-[420px] overflow-y-auto leading-relaxed text-left scrollbar-thin">
                {logs.map((lg) => (
                  <div key={lg.id} className="border-b border-slate-800 pb-2">
                    <div className="flex items-center justify-between gap-2 text-[8px] mb-1">
                      <span className="text-slate-500 font-semibold">{lg.timestamp}</span>
                      <span className={`px-1.5 py-0.2 rounded font-mono font-bold uppercase ${
                        lg.level === 'info' 
                          ? 'bg-blue-950/80 text-blue-400' 
                          : lg.level === 'warn'
                            ? 'bg-amber-950/85 text-amber-400'
                            : 'bg-rose-950/85 text-rose-405'
                      }`}>
                        {lg.level}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-350">
                      <strong className="text-blue-450">{lg.service}:</strong> {lg.message}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-5 border-t border-slate-100 text-[11px] text-slate-500 leading-relaxed font-light mt-4">
              Diagnostic terminal linked to standard API endpoint container on port <span className="font-mono font-semibold text-blue-600">3000</span>. Ephemeral storage loops clean binary hashes per epoch trigger.
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
