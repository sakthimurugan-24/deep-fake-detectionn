/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  ShieldAlert, 
  Shield,
  Cpu, 
  ScanFace, 
  Sparkles, 
  ArrowRight, 
  BarChart3, 
  Lock, 
  Database, 
  Award, 
  FileCheck, 
  Compass, 
  HelpCircle,
  Network 
} from 'lucide-react';
import { HERO_STATS, FEATURES, PIPELINE_WORKFLOW, TESTIMONIALS } from '../data/mockModelStats';

interface LandingPageProps {
  onStartDetection: () => void;
  setCurrentTab: (tab: string) => void;
  isAuthenticated: boolean;
}

export default function LandingPage({
  onStartDetection,
  setCurrentTab,
  isAuthenticated
}: LandingPageProps) {
  return (
    <div id="landing-page" className="min-h-screen bg-[#F8FAFC] text-slate-800 selection:bg-blue-600/10 selection:text-blue-600">
      
      {/* Hero Section */}
      <section id="hero-section" className="mx-auto max-w-7xl px-4 pt-16 pb-20 sm:px-6 lg:px-8 text-center relative">
        {/* Soft elegant corporate badge */}
        <div className="mx-auto inline-flex items-center space-x-1.5 rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700 mb-6 shadow-sm">
          <ShieldAlert className="h-3.5 w-3.5 text-blue-600" />
          <span>Next-Generation Synthetic Media Authentication</span>
        </div>

        {/* Clean, authoritative headline */}
        <h1 className="mx-auto max-w-4xl text-4xl font-extrabold tracking-tight text-slate-900 sm:text-6xl">
          Secure Trust in the Era of{' '}
          <span className="text-blue-600 block sm:inline">Generative Synthetic Media</span>
        </h1>

        <p className="mx-auto mt-6 max-w-2xl text-base sm:text-lg text-slate-600 leading-relaxed font-light">
          DeepShield AI leverages high-frequency GAN pixel wavelet models, convolutional artifact mappings, and vocal acoustic biometrics to identify deepfakes with absolute, court-admissible forensic precision under 450 milliseconds.
        </p>

        {/* Professional CTA buttons */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <button
            id="btn-hero-cta"
            onClick={onStartDetection}
            className="group inline-flex items-center gap-2 rounded-lg bg-blue-600 hover:bg-blue-700 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-blue-550/10 transition-colors cursor-pointer"
          >
            Launch Forensic Scanner
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </button>
          
          <button
            onClick={() => {
              const el = document.getElementById('pipeline-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 px-5 py-3 text-sm font-semibold text-slate-700 transition duration-150 cursor-pointer shadow-sm"
          >
            Explore AI Architecture
          </button>
        </div>

        {/* Hero Preview Clean Component Mockup (Requirement 13 - Anti-AI-slop visual structure) */}
        <div className="mt-14 mx-auto max-w-4xl rounded-xl border border-slate-200 bg-white p-2.5 shadow-md">
          <div className="rounded-lg border border-slate-150 bg-slate-50 overflow-hidden relative">
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-100 border-b border-slate-200">
              <div className="flex space-x-1.5">
                <div className="w-3 h-3 rounded-full bg-slate-250" />
                <div className="w-3 h-3 rounded-full bg-slate-250" />
                <div className="w-3 h-3 rounded-full bg-slate-250" />
              </div>
              <div className="text-[10px] text-slate-500 font-mono tracking-widest uppercase">DeepShield Console — Active Verification Session</div>
              <div className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
            </div>
            
            <div className="p-4 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-6 text-left bg-white">
              <div className="md:col-span-7 space-y-4">
                <div className="border border-blue-100 bg-blue-50/55 rounded-lg p-3.5 space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-bold text-blue-700">
                    <span>ANALYZING FRAME MATRIX (90%)</span>
                    <span>140ms remaining</span>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden border border-slate-200">
                    <div className="h-full bg-blue-600" style={{ width: '90%' }} />
                  </div>
                </div>

                <div className="space-y-1.5 font-mono text-[11px] text-slate-600 bg-slate-50 p-4 rounded-lg border border-slate-200">
                  <p className="text-blue-600"># executing: deepshield_wavelet_scan --target demo_media.png</p>
                  <p className="text-slate-500">&gt; pre-processing frame buffers: 1080p, baseline-aligned successfully</p>
                  <p className="text-slate-500">&gt; high-resolution residual texture calculation: spatial anomalies spotted with 98.4% index</p>
                  <p className="text-rose-600 font-semibold">&gt; CRITICAL: asymmetric eye-reflection rPPG vector mappings detected</p>
                  <span className="text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-250 font-bold inline-block mt-1">
                    STATUS: DEEPFAKE DETECTED (PROBABILITY: 97.4%)
                  </span>
                </div>
              </div>

              <div className="md:col-span-5 flex flex-col justify-center border-t md:border-t-0 md:border-l border-slate-200 pt-6 md:pt-0 pl-0 md:pl-6 space-y-4">
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-center">
                  <div className="text-[10px] tracking-wider text-slate-500 uppercase font-bold">Accuracy Index Benchmark</div>
                  <div className="mt-2 text-4xl font-extrabold text-blue-600 tracking-tight">99.8%</div>
                  <div className="text-[11px] text-slate-500 mt-1">Real-world audited benchmark precision score</div>
                </div>
                <div className="flex justify-between text-xs text-slate-600 px-1">
                  <div className="flex items-center gap-1.5"><FileCheck className="h-3.5 w-3.5 text-blue-600" /> REST API Ready</div>
                  <div className="flex items-center gap-1.5"><Lock className="h-3.5 w-3.5 text-blue-600" /> SOC2 Compliant</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section id="stats-section" className="border-y border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center divide-y lg:divide-y-0 lg:divide-x divide-slate-100">
            {HERO_STATS.map((stat, idx) => (
              <div key={idx} className="space-y-1.5 py-4 lg:py-0 px-2">
                <p className="text-4xl font-extrabold tracking-tight text-blue-600">
                  {stat.value}
                </p>
                <p className="text-sm font-semibold text-slate-900">{stat.label}</p>
                <p className="text-xs text-slate-500">{stat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Breakdown Bento Section */}
      <section id="features-section" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <div className="text-center space-y-3">
          <h2 className="text-xs font-bold tracking-widest text-blue-600 uppercase">Detection Arsenal</h2>
          <p className="text-3xl font-extrabold sm:text-4xl text-slate-950">
            Deep-Analysis Verification Modules
          </p>
          <p className="mx-auto mt-2 max-w-2xl text-sm text-slate-500">
            Unleashing simultaneous forensic checks across audio, video, and image layers to expose synthetic artifacts.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((feature, idx) => {
            // Pick corresponding icon
            let IconComponent = Cpu;
            if (feature.icon === "Cpu") IconComponent = Cpu;
            else if (feature.icon === "ShieldAlert") IconComponent = ShieldAlert;
            else if (feature.icon === "Mic") IconComponent = ScanFace;
            else if (feature.icon === "Sparkles") IconComponent = Sparkles;
            else if (feature.icon === "Video") IconComponent = Network;
            else if (feature.icon === "Database") IconComponent = Database;

            return (
              <div 
                key={idx}
                className="group relative rounded-xl border border-slate-200 bg-white p-5 hover:border-blue-300 hover:shadow-md transition-all duration-200 block"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all duration-200 shadow-sm">
                  <IconComponent className="h-5.5 w-5.5" />
                </div>
                <h3 className="mt-4 text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  {feature.title}
                </h3>
                <p className="mt-2 text-xs text-slate-500 leading-relaxed font-light">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* AI Pipeline Flow Architecture Section */}
      <section id="pipeline-section" className="border-t border-slate-200 bg-white px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="text-center space-y-3 mb-14">
            <h2 className="text-xs font-bold tracking-widest text-blue-600 uppercase">Processing Pipeline</h2>
            <p className="text-3xl font-extrabold sm:text-4xl text-slate-950">
              Algorithm Orchestration Architecture
            </p>
            <p className="mx-auto max-w-2xl text-sm text-slate-500">
              Structured pipeline routes from raw media file packets down to irreversible authenticity reports.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative">
            {PIPELINE_WORKFLOW.map((wf, idx) => (
              <div key={idx} className="relative rounded-xl border border-slate-200 bg-slate-50 p-5 shadow-sm hover:bg-slate-50/50 transition duration-150">
                <div className="flex items-center justify-between">
                  <span className="text-xl font-bold font-mono text-slate-350">
                    {wf.step}
                  </span>
                  <span className="rounded bg-blue-50 px-2 py-0.5 text-[9px] font-bold text-blue-600 uppercase tracking-widest border border-blue-100">
                    {wf.phase}
                  </span>
                </div>
                <h4 className="mt-4 text-sm font-bold text-slate-800">
                  {wf.title}
                </h4>
                <p className="mt-2 text-xs text-slate-500 font-light leading-relaxed">
                  {wf.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials-section" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 border-t border-slate-150">
        <div className="text-center mb-12">
          <h2 className="text-xs font-bold tracking-widest text-blue-600 uppercase">Endorsed Safety</h2>
          <p className="text-3xl font-extrabold text-slate-950 mt-2">
            Trusted by Enterprise & Media Units
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((test, idx) => (
            <div key={idx} className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 shadow-sm hover:border-slate-300 transition duration-150">
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed italic">
                "{test.quote}"
              </p>
              <div className="mt-5 pt-3.5 border-t border-slate-100">
                <p className="text-sm font-bold text-slate-800">{test.author}</p>
                <p className="text-[10px] text-blue-600 font-semibold">{test.role}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Corporate Final Call to Action */}
      <section id="cta-section" className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 text-center bg-blue-50 border border-blue-100 mb-16 rounded-2xl">
        <h2 className="text-2xl font-extrabold text-slate-900 sm:text-4xl">Ready to Audit Synthetic Payloads?</h2>
        <p className="mx-auto mt-3 max-w-xl text-xs sm:text-sm text-slate-500 leading-relaxed font-light">
          Deploy forensic verification layers inside your existing organization or execute instant manual scans for images, audio, and media frames.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <button
            onClick={onStartDetection}
            className="rounded-lg bg-blue-600 px-5 py-3 text-xs font-semibold text-white shadow-sm hover:bg-blue-700 transition cursor-pointer"
          >
            Launch Free Diagnostic Audit
          </button>
          {!isAuthenticated && (
            <button
              onClick={() => setCurrentTab('register')}
              className="rounded-lg border border-slate-250 bg-white hover:bg-slate-50 px-5 py-3 text-xs font-semibold text-slate-700 transition cursor-pointer shadow-sm"
            >
              Sign Up for Console limits
            </button>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer id="footer-section" className="border-t border-slate-200 bg-white py-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-2">
            <span className="text-sm font-semibold text-slate-800 flex items-center gap-1">
              <Shield className="h-4.5 w-4.5 text-blue-600" />
              Deep<span className="text-blue-600">Shield</span>
            </span>
            <span className="text-slate-300">|</span>
            <span className="text-xs text-slate-500">© 2026 Sovereign Cybersecurity Standards Group</span>
          </div>
          <div className="flex items-center space-x-6 text-xs text-slate-500">
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-blue-600 transition font-medium">Security Protocol</a>
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-blue-600 transition font-medium">Compliance Rules</a>
            <a href="#" onClick={(e) => e.preventDefault()} className="hover:text-blue-600 transition font-medium">Developer REST API</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
