/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, BrainCircuit, ShieldCheck, LogOut, LayoutDashboard, UserCheck, HelpCircle } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentUser: User | null;
  onLogout: () => void;
  openChat: () => void;
}

export default function Navbar({
  currentTab,
  setCurrentTab,
  currentUser,
  onLogout,
  openChat
}: NavbarProps) {
  return (
    <header id="header-navbar" className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        {/* Logo/Identity */}
        <div 
          id="brand-logo"
          className="flex cursor-pointer items-center space-x-2 transition-opacity hover:opacity-90"
          onClick={() => setCurrentTab('home')}
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600 text-white shadow-sm shadow-blue-500/20">
            <Shield className="h-5 w-5" />
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="text-lg font-bold tracking-tight text-slate-900">
              Deep<span className="text-blue-600">Shield</span>
            </span>
            <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-semibold text-slate-600 uppercase tracking-wider">
              Enterprise
            </span>
          </div>
        </div>

        {/* Global Navigation Links */}
        <nav id="global-navbar-links" className="hidden md:flex items-center space-x-6">
          <button
            id="nav-link-home"
            onClick={() => setCurrentTab('home')}
            className={`text-sm font-medium transition-colors ${
              currentTab === 'home' 
                ? 'text-blue-600 font-semibold' 
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Overview
          </button>
          <button
            id="nav-link-detector"
            onClick={() => setCurrentTab('detection')}
            className={`text-sm font-medium transition-colors ${
              currentTab === 'detection' 
                ? 'text-blue-600 font-semibold' 
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Forensic Scanner
          </button>
          {currentUser && (
            <button
              id="nav-link-dashboard"
              onClick={() => setCurrentTab('dashboard')}
              className={`text-sm font-medium transition-colors ${
                currentTab === 'dashboard' 
                  ? 'text-blue-600 font-semibold' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Console Desk
            </button>
          )}
          {currentUser?.role === 'admin' && (
            <button
              id="nav-link-admin"
              onClick={() => setCurrentTab('admin')}
              className={`text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentTab === 'admin' 
                  ? 'text-blue-600 font-semibold' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserCheck className="h-4 w-4" /> System Admin
            </button>
          )}
        </nav>

        {/* Quick Action Control Section */}
        <div id="nav-actions" className="flex items-center space-x-3">
          {/* Chat Assistant Shortcut */}
          <button
            id="btn-nav-chat"
            onClick={openChat}
            className="hidden sm:flex items-center space-x-1 border border-slate-200 bg-slate-50 hover:bg-slate-100 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-700 transition"
          >
            <HelpCircle className="h-3.5 w-3.5 text-blue-600" />
            <span>AI Forensic Copilot</span>
          </button>

          {currentUser ? (
            <div id="nav-user-meta" className="flex items-center space-x-3 pl-2 border-l border-slate-250">
              <div className="hidden sm:block text-right">
                <div className="text-xs font-semibold text-slate-800">{currentUser.name}</div>
                <div className="text-[10px] uppercase tracking-wider text-slate-500 font-medium">{currentUser.role} Level</div>
              </div>
              <button
                id="btn-logout"
                onClick={onLogout}
                className="flex items-center justify-center p-2 rounded-lg bg-slate-50 hover:bg-red-50 hover:text-red-600 border border-slate-200 text-slate-500 transition"
                title="Disconnect from platform"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div id="nav-auth-links" className="flex items-center space-x-2">
              <button
                id="btn-nav-login"
                onClick={() => setCurrentTab('login')}
                className="text-xs font-semibold text-slate-600 hover:text-slate-900 transition px-3 py-1.5"
              >
                Sign In
              </button>
              <button
                id="btn-nav-register"
                onClick={() => setCurrentTab('register')}
                className="rounded-lg bg-blue-600 px-3.5 py-1.5 text-xs font-semibold text-white shadow-sm hover:colors hover:bg-blue-700 transition duration-150"
              >
                Launch Console
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
