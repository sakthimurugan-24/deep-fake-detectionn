/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import LandingPage from './components/LandingPage';
import AuthPages from './components/AuthPages';
import Detector from './components/Detector';
import Dashboard from './components/Dashboard';
import AdminPanel from './components/AdminPanel';
import Chatbot from './components/Chatbot';
import { User, AnalysisResult } from './types';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [history, setHistory] = useState<AnalysisResult[]>([]);
  const [sidebarChatOpen, setSidebarChatOpen] = useState(false);
  const [chatbotTopic, setChatbotTopic] = useState<string | undefined>(undefined);

  // Check for active token in local session
  useEffect(() => {
    const savedToken = localStorage.getItem('deepshield_jwt_token');
    const savedUser = localStorage.getItem('deepshield_user');
    if (savedToken && savedUser) {
      setToken(savedToken);
      try {
        const parsed = JSON.parse(savedUser);
        setCurrentUser(parsed);
      } catch (e) {
        console.error("Failed to parse local profile node:", e);
      }
    }
  }, []);

  const handleAuthSuccess = (newToken: string, userData: any) => {
    localStorage.setItem('deepshield_jwt_token', newToken);
    localStorage.setItem('deepshield_user', JSON.stringify(userData));
    setToken(newToken);
    setCurrentUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('deepshield_jwt_token');
    localStorage.removeItem('deepshield_user');
    setToken(null);
    setCurrentUser(null);
    setCurrentTab('home');
  };

  const syncAuditHistory = async () => {
    try {
      const headers: any = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const response = await fetch('/api/history', { headers });
      if (response.ok) {
        const data = await response.json();
        setHistory(data);
      }
    } catch (err) {
      console.error("Failed to sync media audit nodes:", err);
    }
  };

  // Sync state history on load or auth switches
  useEffect(() => {
    syncAuditHistory();
  }, [token]);

  // Insert a newly completed scan into the history log
  const handleAddNewReport = (report: AnalysisResult) => {
    setHistory(prev => [report, ...prev]);
  };

  // Delete/purge callback
  const handleDeleteReport = async (reportId: string) => {
    try {
      const headers: any = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const response = await fetch(`/api/report/${reportId}`, {
        method: 'DELETE',
        headers
      });
      if (response.ok) {
        // Remove locally from state list
        setHistory(prev => prev.filter(r => r.id !== reportId));
      }
    } catch (err) {
      console.error("Failed to purge requested focal logs:", err);
    }
  };

  const handleOpenChatWithTopic = (topic: string) => {
    setChatbotTopic(topic);
    setSidebarChatOpen(true);
  };

  return (
    <div id="deepshield-app-canvas" className="min-h-screen flex flex-col bg-[#F8FAFC] text-slate-900 font-sans selection:bg-blue-600/10 selection:text-blue-600">
      
      {/* Subtle brand blue top indicator (not neon) */}
      <div className="h-0.5 w-full bg-blue-600" />

      {/* Global Navigation header */}
      <Navbar 
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currentUser={currentUser}
        onLogout={handleLogout}
        openChat={() => {
          setChatbotTopic(undefined);
          setSidebarChatOpen(prev => !prev);
        }}
      />

      {/* Content Canvas frame */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <LandingPage 
            onStartDetection={() => setCurrentTab('detection')}
            setCurrentTab={setCurrentTab}
            isAuthenticated={!!currentUser}
          />
        )}

        {currentTab === 'detection' && (
          <Detector 
            onAddHistoryItem={handleAddNewReport}
            token={token}
            onOpenChatWithTopic={handleOpenChatWithTopic}
          />
        )}

        {currentTab === 'dashboard' && currentUser && (
          <Dashboard 
            currentUser={currentUser}
            history={history}
            onDeleteReport={handleDeleteReport}
            token={token}
            setCurrentTab={setCurrentTab}
            onRefreshData={syncAuditHistory}
          />
        )}

        {currentTab === 'admin' && currentUser?.role === 'admin' && (
          <AdminPanel 
            token={token}
          />
        )}

        {currentTab === 'login' && (
          <AuthPages 
            initialMode="login"
            onAuthSuccess={handleAuthSuccess}
            setCurrentTab={setCurrentTab}
          />
        )}

        {currentTab === 'register' && (
          <AuthPages 
            initialMode="register"
            onAuthSuccess={handleAuthSuccess}
            setCurrentTab={setCurrentTab}
          />
        )}
      </main>

      {/* Persistent global chatbot widgets floating */}
      {sidebarChatOpen && (
        <Chatbot 
          onClose={() => setSidebarChatOpen(false)}
          initialTopic={chatbotTopic}
        />
      )}
    </div>
  );
}
