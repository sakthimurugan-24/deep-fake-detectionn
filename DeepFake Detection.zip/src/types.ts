/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
  createdAt: string;
}

export interface HeatmapPoint {
  x: number; // percentage from left
  y: number; // percentage from top
  radius: number; // size
  label: string;
}

export interface AnalysisResult {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: string;
  timestamp: string;
  fakeProbability: number; // 0 - 100
  confidenceScore: number; // 0 - 100
  classification: 'Real' | 'Suspicious' | 'Deepfake';
  heatmap: HeatmapPoint[];
  evidence: string[];
  sections: {
    noiseAnalysis: string;
    lightingAnalysis: string;
    geometricInconsistency: string;
    facialFrequencyAnomalies: string;
  };
  userId: string | null;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export interface ModelStatus {
  name: string;
  version: string;
  latency: string;
  status: 'Online' | 'Intermittent' | 'Offline';
  accuracy: string;
  load: string;
}

export interface SystemLog {
  id: string;
  timestamp: string;
  service: string;
  level: 'info' | 'warn' | 'error';
  message: string;
}
