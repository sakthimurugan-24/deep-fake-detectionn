/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ModelStatus, SystemLog } from '../types';

export const HERO_STATS = [
  { value: "99.8%", label: "Model Accuracy", desc: "Industry benchmark precision rate" },
  { value: "4.2M+", label: "Files Audited", desc: "Media streams processed globally" },
  { value: "<450ms", label: "Analysis Latency", desc: "Real-time verification speed" },
  { value: "100%", label: "GDPR Compliant", desc: "Fully private ephemeral processing" }
];

export const FEATURES = [
  {
    title: "GAN Artifact Extraction",
    description: "Detect microscopic statistical anomalies left behind by Generative Adversarial Networks (StyleGAN, Stable Diffusion, Midjourney, etc.) in high-frequency noise bands.",
    icon: "Cpu"
  },
  {
    title: "Facial Wavelet Transform",
    description: "Analyze pixel-level frequency spectra of eyes, lips, and eyelashes to uncover dynamic synthesis blurs invisible to the naked eye.",
    icon: "ShieldAlert"
  },
  {
    title: "Vocal Clone Biometrics",
    description: "Decrypt acoustic phase inconsistencies and synthetic resonance trails to accurately spot ElevenLabs or custom audio voice deepfakes.",
    icon: "Mic"
  },
  {
    title: "Spatial Light Alignment",
    description: "Model 3D facial vectors to cross-reference multiple light source positions, highlighting mismatched ambient reflection artifacts.",
    icon: "Sparkles"
  },
  {
    title: "Temporal Continuity Check",
    description: "Analyze frame-to-frame transitional continuity and blood-flow micro-fluctuations (rPPG) in fast-moving videos.",
    icon: "Video"
  },
  {
    title: "Blockchain Verification Badge",
    description: "Optionally anchor media audit reports into an immutable ledger hash, ensuring absolute chain-of-custody verification.",
    icon: "Database"
  }
];

export const PIPELINE_WORKFLOW = [
  {
    step: "01",
    phase: "Media Ingestion",
    title: "Secure Upload & Validation",
    description: "Files are parsed, sanitized, and structurally verified. MD5/SHA256 hashes are logged for tamper verification.",
    status: "active"
  },
  {
    step: "02",
    phase: "Image preprocessing",
    title: "Region of Interest (ROI) Alignment",
    description: "Facial landmarks are localized and key auditory wave segments are isolated using fast Fourier transform filters.",
    status: "pending"
  },
  {
    step: "03",
    phase: "Feature Extractions",
    title: "High-Frequency Noise Mapping",
    description: "Extracts texture-level GAN fingerprint residue, spatial gradients, and lighting direction vectors.",
    status: "pending"
  },
  {
    step: "04",
    phase: "Deep Neural Check",
    title: "Bento Multi-Model Classification",
    description: "Concurrent validation across deep ResNet, EfficientNet, and audio spectrogram transformers.",
    status: "pending"
  },
  {
    step: "05",
    phase: "Anomaly heatmapping",
    title: "Spatial Heatmap Generation",
    description: "Anomalous neural classification weights are back-propagated to project localized deepfake probability circles.",
    status: "pending"
  },
  {
    step: "06",
    phase: "Signature Audits",
    title: "Immutable Report Generation",
    description: "Export full forensic breakdowns as cryptographic PDFs ready for enterprise compliance and legal teams.",
    status: "pending"
  }
];

export const TESTIMONIALS = [
  {
    quote: "DeepShield AI changed how our newsroom verifies citizen-submitted video. We solved three massive fake-media propaganda scares within weeks.",
    author: "Elena Rostov",
    role: "Director of Integrity, WorldNews Corp"
  },
  {
    quote: "The GAN artifact analysis is spectacular. It's the only platform that consistently catches synthetic facial skin texture blending from model pipelines.",
    author: "Dr. Marcus Vance",
    role: "Senior AI Researcher, CyberDefense Group"
  },
  {
    quote: "Brilliant UI and incredibly solid APIs. Seamlessly integrated into our automated trust & safety pipeline.",
    author: "Sarah Jenkins",
    role: "VP Trust & Safety, StreamVibe"
  }
];

export const INITIAL_AI_MODELS: ModelStatus[] = [
  { name: "ShieldNet-Image (ResNet-101)", version: "v4.2.1", latency: "140ms", status: "Online", accuracy: "99.8%", load: "12%" },
  { name: "ShieldNet-Video (3D-CNN+rPPG)", version: "v3.1.0", latency: "420ms", status: "Online", accuracy: "98.4%", load: "18%" },
  { name: "SynthWave-Audio (Spectrogram Transformer)", version: "v2.5.2", latency: "280ms", status: "Online", accuracy: "99.1%", load: "8%" },
  { name: "GAN-Artifact-Aura (Frequency Wavelet)", version: "v1.9.8", latency: "90ms", status: "Online", accuracy: "99.6%", load: "4%" }
];

export const INITIAL_SYSTEM_LOGS: SystemLog[] = [
  { id: "log-1", timestamp: "06-02 06:45:01", service: "Neural Classifier", level: "info", message: "Model ShieldNet-Image loaded weights seamlessly (Size: 450MB)." },
  { id: "log-2", timestamp: "06-02 06:47:12", service: "Blockchain Registry", level: "info", message: "Verification ledger node sync established with host ether-main-01." },
  { id: "log-3", timestamp: "06-02 06:50:55", service: "Media Preprocessor", level: "info", message: "Auto-cleanup task completed - purged 142 expired ephemeral media buffers." },
  { id: "log-4", timestamp: "06-02 06:52:19", service: "Security Rate Limiter", level: "warn", message: "IP rate limit warning issued to /api/analyze crawler from subnet 185.x" },
  { id: "log-5", timestamp: "06-02 06:54:30", service: "AI Inference Engine", level: "info", message: "Successfully executed batch prediction for ID report_8f3d1" }
];
