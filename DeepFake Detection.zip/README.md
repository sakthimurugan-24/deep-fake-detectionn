# DeepShield AI – Deepfake Detection Platform

DeepShield AI is a modern, responsive, and enterprise-grade full-stack threat verification and media authenticity platform utilizing state-of-the-art Generative Adversarial Network (GAN) artifact extraction, facial wavelet transform spectrum analysis, acoustic formant biometrics, and bilateral specular reflection maps.

## Tech Stack
* **Frontend:** React.js, Tailwind CSS (glowing high-density design, custom SVG analytics charting)
* **Backend:** Node.js, Express.js (MVC server setup, local ephemeral db structure with auto-generated salts)
* **AI Engine:** Dual-lane setup utilizing Gemini 3.5 Flash for actual image forensics, coupled with seed-based computational signal algorithms for deterministic MP4 and audio waveform analysis
* **JWT Authentications:** Base64 token generation mapping roles, secure user state parameters, and staff registers.

---

## Technical Features

### 1. High-Frequency GAN Wavelet Transform
Traditional camera sensors capture light patterns conforming closely to physical Gaussian structures. Generative models (e.g., GANs, Stable Diffusion, Midjourney) write pixels during upsampling and convolutional grids, leaving microscopic, repeating lattice anomalies. DeepShield isolates these frequency layers in color channels.

### 2. Bilateral Specular Reflection
The platform uses the Google Gemini 3.5 Flash vision capability to analyze eye pupil reflections and facial bone structure. Mismatched light ray refraction paths are flagged as anomalous, showing localized heatmaps detailing the probability of manipulation.

### 3. Voice Clone Phase Discrepancies
By performing Fast Fourier Transforms (FFT) on wave uploads, spectrogram transformers catch synthetic formant spikes, phase clipping, and artificial ground-floor noise blocks common to AI voice clone algorithms.

---

## Directory Architecture
```
├── /data/                  <- Simulated SQL database directory
│   └── db.json             <- Immutable secure profile & report seeds
├── /src/
│   ├── /components/
│   │   ├── Navbar.tsx      <- Global navigation header
│   │   ├── LandingPage.tsx <- High-polish cybersecurity portal
│   │   ├── Detector.tsx    <- Interactive drag-drop scanner
│   │   ├── Dashboard.tsx   <- Console history logs & SVG graphing
│   │   ├── AdminPanel.tsx  <- Model latency & staff credential management
│   │   └── Chatbot.tsx     <- AI-powered expert defensive assistant
│   ├── /data/
│   │   └── mockModelStats.ts <- Seed metrics, features, testimonials data
│   ├── App.tsx             <- Global react state & route hub
│   ├── main.tsx            <- Application initialization entry
│   └── types.ts            <- Shared TypeScript interfaces
├── server.ts               <- Express web ingress server (port 3000 mapping)
└── package.json            <- System controls and package definitions
```

---

## Quick-Start Setup

Ensure all framework dependencies are loaded initially:
```bash
npm install
```

### 1. Running the Local sandbox Development Node
The dev server launches in parallel with live asset compilation on port 3000:
```bash
npm run dev
```

### 2. Compiling production bundle distributions
```bash
npm run build
```

---

*Authored by the Sovereign Trust and Safety Security Standards Association.*
